This file will be updated with further information at a later date.

This is a chrome extension that will simply stores tabs of web browsing sessions, allowing easy access to recent collections of tabs.
