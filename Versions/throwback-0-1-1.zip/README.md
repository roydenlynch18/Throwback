This file will be updated with further information at a later date.

This is a chrome extension that will simply stores tabs of web browsing sessions, allowing easy access to recent collections of tabs.

=================
== VERSION LOG ==
=================

V 0.1.0
  Description:
    Version 0.1.0 is the first officially released and published version of
    Throwback. It is essentially, a 'first draft draft' of the extension.
    It includes mostly the barebones functionality of the extension, in addition
    to very limited graphical elements. The extension can seemingly successfully
    add new sessions, save sessions of tabs, open sessions of tabs, and close
    sessions of tabs. Since this is the purpose of the program in essence, it
    represents a successful first step, however, it illustrates much more that
    needs to be done.

  Logged Changes:
    - Extension Created
    - Popup Displays Sessions in Rows
    - Popup Begins w/ One Row
    - Can Add a New Session or Wipe All Sessions
    - Add Session Button Prompts User for Name
    - New Sessions Can Be Added to Save or Open a Collection of Tabs
    - Individual Sessions Can Be Closed (Deleted)

V 0.1.1
  Description:
    Version 0.1.1 strived to make slight improves on most general areas of the
    extension, with a specific focus on the graphical interface of the extension.
    I used an imaging editing software to create my own icons to be used on the
    as the representation of the extension, as well as icons to be used for each
    button on the popup page of the application.

  Logged Changes:
    - New Extension Icons
    - New Popup Icons
